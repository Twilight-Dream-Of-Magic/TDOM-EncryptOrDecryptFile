#Information 信息

##This is the root directory where the (MAKEFILE) executes the compilation in this Code project. 
##Request you, absolutely do not delete it!
-----
##这是一个，在这个代码工程里面的，(MAKEFILE)执行编译的根目录。
##请求你，绝对不要删除它!