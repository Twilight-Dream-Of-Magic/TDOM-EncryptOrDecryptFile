------------------------------------------------------------------------------------------------------------------------

English

1.At present this procedure, only need to do some landscaping, as well as detailed adjustments to the manual.

2.Do not need to do much change.

3.Of course, if you need to change it. Give me a better suggestion, let me write this procedure.



This code repository consists of [Twlilght-Dream-Of-Magic] Twlilght_Yujiang author, compiled and built!

IDE: Integrated development environment

It is best not to use Code Block IDE, to build this project!



Best to use Makefile build project!

If you need to view my Makefile help, the command line input [make help].

This Makefile file

Applicable to (Microsoft Windows) system (already completed, the code has BUG please Github message)

Applicable to (Linux) system (still in plan .......)



If you want to use the IDE to build this project, please distinguish between each version!

This warehouse, each version of the project folder, please create a new IDE project file, and then associated!

------------------------------------------------------------------------------------------------------------------------

Chinese

1.目前这个程序，只需要做一些美化，还有说明书的详细调整。

2.不需要做什么太大的改动。

3.当然，如果你需要改动的话。给我更好的建议，让我去编写这个程序。



这个代码仓库由 [Twlilght-Dream-Of-Magic] Twlilght_Yujiang 作者，编译和构建!

IDE ： 集成开发环境

最好不要使用Code Block IDE，来构建这个工程！



最好使用Makefile构建工程!

如果需要，查看我的Makefile帮助，命令行输入[make help]

这个Makefile文件

适用于(Microsoft Windows)系统 (已经完成，代码有BUG请在Github上留言)

适用于(Linux)系统 (还在计划中.......)



如果你要使用IDE构建这个工程，请区分每一个版本！

这个仓库，每一个版本的工程文件夹，请新建一个IDE工程文件，然后关联!

------------------------------------------------------------------------------------------------------------------------
