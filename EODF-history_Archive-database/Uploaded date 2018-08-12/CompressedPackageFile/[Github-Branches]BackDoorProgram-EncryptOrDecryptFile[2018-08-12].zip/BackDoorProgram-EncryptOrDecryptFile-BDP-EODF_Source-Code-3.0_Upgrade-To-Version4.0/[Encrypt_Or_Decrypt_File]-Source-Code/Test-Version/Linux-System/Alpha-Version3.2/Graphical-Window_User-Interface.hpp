#include "Support-Libary.hpp"

using namespace std;

//Qt5 Libary

int GWUI()
{
  //Use code to make function, this is a to-do item
  //使用代码来制作功能，这是一个待办事项
  cout << "Maybe this functional code is coming soon ......" << endl;
  return 0;
}
