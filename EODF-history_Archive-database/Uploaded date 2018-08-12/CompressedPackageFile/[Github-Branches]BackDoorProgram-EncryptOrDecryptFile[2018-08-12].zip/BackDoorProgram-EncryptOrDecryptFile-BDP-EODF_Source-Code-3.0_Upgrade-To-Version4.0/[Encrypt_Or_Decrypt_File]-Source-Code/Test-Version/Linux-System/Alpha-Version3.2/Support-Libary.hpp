#include <iostream>
#include <fstream>
#include <cstdio>
#include <ctime>

#include <unistd.h>
#include <stdio.h>   //计算机C语言标准输入输出函数 Computer C language standard input and output functions
#include <stdlib.h>  //计算机C语言标准库函数 Computer C language standard library functions
#include <string.h>  //计算机C语言字符串处理函数 Computer C language string handling functions
#include <time.h>

using namespace std;

//#pragma once
