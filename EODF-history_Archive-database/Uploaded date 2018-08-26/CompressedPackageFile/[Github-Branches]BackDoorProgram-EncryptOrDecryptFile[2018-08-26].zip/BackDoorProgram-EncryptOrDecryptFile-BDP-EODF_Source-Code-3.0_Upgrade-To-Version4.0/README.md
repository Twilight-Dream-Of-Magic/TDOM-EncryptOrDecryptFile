# About the c-plus-plus code project



---



## English

### 1.At present this procedure, only need to do some landscaping, as well as detailed adjustments to the manual.

### 2.So, do not need to do much change for code.

### 3.Of course, if you need me to change code it. ●
### Please give me a better suggestion, let me write this procedure(program). ●

### 4. Sometimes the test version of the project (Preview test version code project), there will be some new test functions and change the code structure. ▲
### If the code (75%) is changed too much, it may not be compatible with the previous version. ▲
### Although, they may be problematic code or the code that does not fully implement my idea. However, this is my new attempt to upgrade the code every time.(Maybe, what can I do it this?) ▲
### This will make me progress in programming techniques. I share my the little achievements of programming made me feel satisfied. ▲
### In addition, I very much welcome everyone to help me. For those who can give me, financial sponsorship and technical support, I would like to express my strong gratitude and thank you for your attention and support! ◆

### 5. A method for file encoding format for languages in the world.
### Because my is a Chinese in Asia, I use the Windows 10 Professional Edition system.
### So for the binaries and source code files for Windows and the scripts for building projects, the language encoding format I set is the GBK standard.
### Because I have considered that the program needs to support at the same time, showing the internationalization and localization of the text language. So the types of language text are Chinese and English, and they are displayed together.
### Also, for binary programs and source code files for Linux and scripts for building projects, the language encoding format I set is the UTF-8 standard.
### Actually my English level is not very good, and then most of the Chinese translation into English, I have given it to Google to help. Thanks to Google's tools, really a practical website!
### If you have the content of the error translation, you are welcome to point out the errors and translation suggestions.
### Finally, I wish you all a good time and enjoy it.



---



### *FAQ*

#### This code repository consists of [Twilight-Dream-Of-Magic] author, compiled and built!

#### IDE: Integrated development environment

#### ~~It is best not to use Code Block IDE, to build this project!~~

#### ~~Although i provided the [.cbp] file! (Code Block Project File)~~



#### How to build this project?

#### The best option is to use Makefile to build this project!

#### If you need to view the script file for my provided.

#### (Makefile) command help information, please use the command line to enter `make help` in the same directory of this file.

#### The above content is about the description of this Makefile.



### *Status of this project progress*

#### Applicable to (Microsoft Windows) system:

#### Already completed, the code has BUG please Github message.



#### Applicable to (Open Source Linux) system:

#### Now with this plan for this Linux platform, the completed source code will soon appear!
#### Maybe I need a month of testing time to continue debugging the program.



### *If you want to use the IDE to build this project, please distinguish between each version!*

### *This repository (knowledge warehouse), each version of the project folder, please create a new IDE project file, and then associated it!*



---



# 关于这个C++代码项目

## Chinese

### 1.目前这个程序，只需要做一些美化，还有说明书的详细调整。

### 2.所以，不需要为代码做太多改变。

### 3.当然，如果你需要我改动代码的话。 ●
### 请给我更好的建议，让我去编写这个程序。 ●

### 4.有时候测试版本项目(Preview test version code project)，将会有一些新的测试功能和改变代码结构。 ▼
### 如果发生了太大改变的代码(75%)，也许会让它与以前版本不具有兼容性。 ▼
### 尽管，它们可能是有问题的代码或者没有把我的想法来完全实现的代码。然而，这都是我每一次升级代码的新尝试。(也许，我能够做到的？) ▼
### 这会让我有编程技术的进步，我分享我的编程小成就，使我得到满足的感觉。 ▼
### 另外，我非常欢迎大家来帮助我，对于那些能够给予我，资金赞助和技术支持的人们，我表示强烈的感谢，谢谢大家的关注和支持! ★

### 5.关于世界地区语言的文件编码格式的方法。
### 因为本人作者是亚洲的中国人，使用的是 Windows 10 专业版本系统。
### 所以用于 Windows 的二进制程序和源代码文件和构建项目的脚本，我设置的语言编码格式是 GBK 标准。
### 因为本人考虑到，程序需要同时支持，显示文字语言的国际化和本地化。所以语言文字的类型是中文和英文，一起来显示它们。
### 此外，用于 Linux 的二进制程序和源代码文件和构建项目的脚本，我设置的语言编码格式是 UTF-8 标准
### 其实我的英语的水平不是很好，然后大部分的中文翻译为英语，我都交给了谷歌来帮忙了。谢谢谷歌的工具，真的是实用的网站！
### 如果有错误翻译的内容，欢迎大家的指出错误和翻译建议。
### 最后，祝你们使用愉快，享受它吧。



---



### *FAQ*

#### 这个代码仓库由 [Twilight-Dream-Of-Magic] 作者，编译和构建!

#### IDE ： 集成开发环境

#### ~~最好不要使用Code Block IDE，来构建这个工程！~~

#### ~~虽然我提供了[.cbp]文件！(Code Block Project File)~~



#### 怎么构建这个项目？

#### 最好的选择，是你使用Makefile构建这个工程!

#### 如果你需要查看，我提供的脚本文件。

#### (Makefile)的命令帮助信息，请在这个文件的同一个目录下，使用命令行输入 `make help`

#### 以上的内容，是关于这个Makefile文件的说明



### *这个项目进行进度的状态*

#### 适用于(Microsoft Windows)系统：

#### 已经完成，代码有BUG请在Github上留言



#### 适用于(Linux)系统：

#### 现在关于这个Linux平台的这个计划，已经很快就会出现完成的源代码！也许我需要一个月的测试时间，来继续进行调试着程序......



### *如果你要使用IDE构建这个工程，请区分每一个版本！*

### *这个仓库，每一个版本的工程文件夹，请新建一个IDE工程文件，然后关联!*



---
